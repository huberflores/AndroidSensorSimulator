The ant script in this directory will generate the
complete OpenIntents SensorSimulator release.

* sensorsimulator-x.x.x.zip

Run "ant build.xml" to see the list of possible targets.
See the comments in "build.xml" for necessary properties.
